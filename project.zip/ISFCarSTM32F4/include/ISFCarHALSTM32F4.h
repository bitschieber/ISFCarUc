/*
 * ISFCarHALSTM32F4.h
 *
 *  Created on: 04.08.2015
 *      Author: Alex
 */

#ifndef ISFCARHALSTM32F4_H_
#define ISFCARHALSTM32F4_H_

#include "stm32f4xx_hal.h"
#include "gpio.h"
#include "adc.h"
#include "tim.h"
#include "usart.h"

class ISFCarHAL_STM32F4 {
public:
	ISFCarHAL_STM32F4();
	virtual ~ISFCarHAL_STM32F4();
	void SystemClock_Config(void);
};

#endif /* ISFCARHALSTM32F3_H_ */
