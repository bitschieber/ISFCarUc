The system_stm32f4xx.c file is from stm32cubef4.zip, the folder:

	STM32Cube_FW_F4_V1.1.0/Drivers/CMSIS/Device/ST/STM32F4xx/Source/Templates

The vectors_stm32f4xx.c was created to conform to the startup_stm32f4xxxx.s.