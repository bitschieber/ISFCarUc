These files are from stm32cubef4.zip, v1.4.0, the folder

	STM32Cube_FW_F4_V1.4.0/Drivers/CMSIS/Device/ST/STM32F4xx/Include

The cmsis_device.h is added for convenience.

